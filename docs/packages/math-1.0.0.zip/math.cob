# math.cob — integer math operations for Cob
#
# THE CONTRACT (read this first)
# --------------------------------
# Cob has no functions, so there's no `math.factorial(5)`. Instead
# this file is a DISPATCHER: you set two inputs and an operation code,
# shuck this file, and it fills in one output. Every variable is
# prefixed `math_` -- see seed.cob's template if you're new to why.
#
#   math_op      which operation to run (table below)
#   math_a        first argument
#   math_b        second argument (ignored by unary ops)
#   math_result   the output, once shuck returns
#
#   op 1  factorial(a)         b ignored     0! and negative a both -> 1
#   op 2  gcd(a, b)
#   op 3  power(a, b)          a^b, b >= 0
#   op 4  abs(a)                b ignored
#   op 5  min(a, b)
#   op 6  max(a, b)
#   op 7  tally                 prints math_result as up to 50 '*'
#                                lines -- a crude bar/health-meter effect,
#                                since pop() can't print a number directly
#
# Each operation is a `while math_op == N:` block that runs its body
# at MOST once, because the body itself changes what made the condition
# true -- that's how you get if/then out of a language that only has
# while. math_op is consumed (reset to 0) when its block runs, so
# it's safe to shuck this file again for another operation in the same
# program.
#
# No parentheses exist in Cob's expression grammar -- every formula
# below is written so `*`/`/` (same precedence, left-to-right) and
# `+`/`-` combine correctly without needing them.

while math_op == 1:
    set math_result = 1
    set math_i = math_a
    while math_i > 1:
        set math_result = math_result * math_i
        set math_i = math_i - 1
    set math_op = 0

while math_op == 2:
    set math_x = math_a
    set math_y = math_b
    while math_y != 0:
        set math_r = math_x - math_x / math_y * math_y
        set math_x = math_y
        set math_y = math_r
    set math_result = math_x
    set math_op = 0

while math_op == 3:
    set math_result = 1
    set math_i = 0
    while math_i < math_b:
        set math_result = math_result * math_a
        set math_i = math_i + 1
    set math_op = 0

while math_op == 4:
    set math_result = math_a
    while math_result < 0:
        set math_result = 0 - math_result
    set math_op = 0

while math_op == 5:
    set math_result = math_a
    while math_b < math_result:
        set math_result = math_b
    set math_op = 0

while math_op == 6:
    set math_result = math_a
    while math_b > math_result:
        set math_result = math_b
    set math_op = 0

while math_op == 7:
    set math_tally_n = math_result
    while math_tally_n < 0:
        set math_tally_n = 0
    while 50 < math_tally_n:
        set math_tally_n = 50
    set math_tally_i = 0
    while math_tally_i < math_tally_n:
        pop("*")
        set math_tally_i = math_tally_i + 1
    set math_op = 0
