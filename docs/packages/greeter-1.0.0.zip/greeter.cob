# greeter -- a tiny example Cob package, published via farmer
pop("greeter v1.0.0 loaded")
set greetings_given = 0
